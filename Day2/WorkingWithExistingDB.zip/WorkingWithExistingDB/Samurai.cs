﻿using System;
using System.Collections.Generic;

namespace WorkingWithExistingDB;

public partial class Samurai
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public virtual ICollection<Quote> Quotes { get; } = new List<Quote>();
}
