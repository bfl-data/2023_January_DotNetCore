﻿using App.Domain;

namespace App.UI
{
    internal class Program
    {
        private static Data.AppContext appContext = new Data.AppContext();
        static void Main(string[] args)
        {
            // Should not be used in production
            //appContext.Database.EnsureCreated();
            GetSamurais("First Load: ");
            AddSamurai();
            GetSamurais("After Add: ");
            Console.WriteLine("Press any key....");
            Console.ReadKey();
        }

        private static void AddSamurai()
        {
            var samurai = new Domain.Samurai() { Name = "Sampson" };
            appContext.Samurais.Add(samurai);
            appContext.SaveChanges();
        }

        private static void GetSamurais(string text)
        {
            var samurais = appContext.Samurais.ToList();
            Console.WriteLine($"{text}: Samurai count is {samurais.Count}");
            foreach (var samurai in samurais)
            {
                Console.WriteLine(samurai.Name);
            }
        }
    }
}