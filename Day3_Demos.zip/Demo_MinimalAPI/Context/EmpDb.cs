﻿using Demo_MinimalAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace Demo_MinimalAPI.Context
{
    public class EmpDb : DbContext
    {
        public EmpDb(DbContextOptions<EmpDb> options)
        : base(options) { }

        public DbSet<Employee> Employees => Set<Employee>();
    }
}
