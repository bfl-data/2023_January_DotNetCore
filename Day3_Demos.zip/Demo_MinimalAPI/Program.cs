using Demo_MinimalAPI.Context;
using Demo_MinimalAPI.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<EmpDb>(opt => opt.UseInMemoryDatabase("EmployeeList"));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

var app = builder.Build();

app.MapGet("/employees", async (EmpDb db) =>
    await db.Employees.ToListAsync());

app.MapGet("/employees/{id}", async (int id, EmpDb db) =>
    await db.Employees.FindAsync(id)
    is Employee employee
    ? Results.Ok(employee)
    : Results.NotFound());

app.MapPost("/employees", async (Employee emp, EmpDb db) =>
{
    db.Employees.Add(emp);
    await db.SaveChangesAsync();

    return Results.Created($"/employees/{emp.Id}", emp);
});

app.MapPut("/employees/{id}", async (int id, Employee emp, EmpDb db) =>
{
    var e = await db.Employees.FindAsync(id);

    if (e is null) return Results.NotFound();

    e.Name = emp.Name;
    e.Designation = emp.Designation;

    await db.SaveChangesAsync();

    return Results.NoContent();
});

app.MapDelete("/employees/{id}", async (int id, EmpDb db) =>
{
    if(await db.Employees.FindAsync(id) is Employee employee)
    {
        db.Employees.Remove(employee);
        await db.SaveChangesAsync();
        return Results.Ok(employee);
    }

    return Results.NotFound();
});

app.Run();