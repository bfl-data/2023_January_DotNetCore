using Demo_Middlewares;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.Use(async (context, next) =>
{
    context.Response.ContentType = "text/html";
    await context.Response.WriteAsync("Request - Middleware One</br>");
    await next.Invoke();
    await context.Response.WriteAsync("Response - Middleware One</br>");
});

app.UseCustomLoggingMiddleware();

app.Use(async (context, next) =>
{
    await context.Response.WriteAsync("Request - Middleware Two</br>");
    await next.Invoke();
    await context.Response.WriteAsync("Response - Middleware Two</br>");

});

app.Use(async (context, next) =>
{
    await context.Response.WriteAsync("Request - Middleware Three</br>");
    await next.Invoke();
    await context.Response.WriteAsync("Response - Middleware Three</br>");
});

app.Map("/branch", (appBuilder) =>
{
    appBuilder.Use(async (context, next) =>
    {
        await context.Response.WriteAsync("--Branch 1 - Request - Middleware One</br>");
        await next.Invoke();
        await context.Response.WriteAsync("--Branch 1 - Response - Middleware One</br>");
    });

    appBuilder.Use(async (context, next) =>
    {
        await context.Response.WriteAsync("--Branch 1 - Request - Middleware Two</br>");
        await next.Invoke();
        await context.Response.WriteAsync("--Branch 1 - Response - Middleware Two</br>");
    });
});

app.UseWhen(context => context.Request.Path.StartsWithSegments("/api"), appBuilder =>
{
    appBuilder.Use(async (context, next) =>
    {
        await context.Response.WriteAsync("-- UseWhen - Url starts with api</br>");
        await next.Invoke();
    });
});

app.MapGet("/", () => "<h3>Hello World!</h3>");

app.Run();
